function loadGame(gameUrl) {
  window.open(gameUrl, '_blank');
}

function updateOnlineUsers() {
  const baseUsers = 250;
  const variance = Math.floor(Math.random() * 100);
  const currentUsers = baseUsers + variance;
  
  document.getElementById('user-count').textContent = currentUsers;
}

document.addEventListener('DOMContentLoaded', () => {
  const searchInput = document.getElementById('game-search');
  const gameCards = document.querySelectorAll('.game-card');
  
  searchInput.addEventListener('input', (e) => {
    const searchTerm = e.target.value.toLowerCase();
    
    gameCards.forEach(card => {
      const gameName = card.dataset.name.toLowerCase();
      card.style.display = gameName.includes(searchTerm) ? 'block' : 'none';
    });
  });

  // Update online users immediately and then every minute
  updateOnlineUsers();
  setInterval(updateOnlineUsers, 60000);
});